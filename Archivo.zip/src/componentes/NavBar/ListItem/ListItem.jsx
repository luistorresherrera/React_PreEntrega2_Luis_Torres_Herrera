import React from "react";
import "./ListItem.css";

const ListItem = (props) => {
  return <li>{props.ItemName}</li>;
};

export default ListItem;
