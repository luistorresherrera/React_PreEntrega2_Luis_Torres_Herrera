import { useEffect, useState } from "react";

export const useFetch = async (url) => {
  // return new Promise(function (resolve) {
  let result = [];
  result = await fetch(url);
  console.log("resuklt", result);
  const resultJSon = await result.json();
  console.log("resultJson", resultJSon);
  return resultJSon;
  // setTimeout(() => {
  // await fetch(url)
  //   .then((response) => response.json())
  //   .then((data) => {
  //     // resolve(data);
  //     result = data;
  //     return data;
  //   })
  //   .catch((error) => {
  //     return error;
  //   });
  // }, 100);
  // });
};

// const [datos, setdatos] = useState([]);

// // useEffect(() => {
//   setTimeout(() => {
//     fetch(url)
//       .then((response) => response.json())
//       .then((data) => setdatos(data))
//       .catch((error) => console.log(error));
//   }, 0);
// }, []);

// return datos;
// };

// export default UseFetch;
