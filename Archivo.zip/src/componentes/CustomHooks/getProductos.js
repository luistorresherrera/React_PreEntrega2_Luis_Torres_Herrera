import { useFetch } from "./UseFetch";

export const getProductosPorCategoria = async (idCat) => {
  const fetchProductos = await useFetch("./src/db/productos.json");
  console.log("fetchProducts", fetchProductos);
  let productosCategoria = [];
  if (idCat) {
    productosCategoria = fetchProductos.filter(
      (item) => item.categoriaProducto == idCat
    );
  } else {
    productosCategoria = fetchProductos;
  }

  return productosCategoria;
};

export const getDetalleProducto = (idItem) => {
  //   console.log(url);
  //   const fetchProductos = useFetch("./src/db/productos.json");
  //   const productoIndividual = fetchProductos.find(
  //     (item) => item.idProducto == idItem
  //   );
  //   return productoIndividual;
};
