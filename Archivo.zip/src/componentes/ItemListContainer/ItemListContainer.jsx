import ProductList from "./ProductList/ProductList";

import "./ItemListContainer.css";
import { useParams } from "react-router-dom";
import { getProductosPorCategoria } from "../CustomHooks/getProductos";
import { useEffect, useState } from "react";

const ItemListContainer = ({ greeting }) => {
  const [productos, setProductos] = useState([]);
  const { idCategoria } = useParams();

  // useEffect(() => {
  const productosX = getProductosPorCategoria(idCategoria).then((x) => {
    setProductos(x);
  });
  console.log(productosX);
  //   setProductos(productosX);
  // }, [idCategoria]);

  return (
    <>
      <h2 className="titlepage" style={{ textAlign: "center", color: "black" }}>
        {greeting}
      </h2>
      <ProductList producto={productos} />
    </>
  );
};

export default ItemListContainer;
